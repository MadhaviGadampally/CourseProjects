-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 07, 2021 at 04:47 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airlineticketreservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `flightdetails`
--

CREATE TABLE `flightdetails` (
  `id` int(11) NOT NULL,
  `flight_number` varchar(20) NOT NULL,
  `airways_name` varchar(40) NOT NULL,
  `origin_airport_name` varchar(40) NOT NULL,
  `origin_city` varchar(20) NOT NULL,
  `origin_country` varchar(30) NOT NULL,
  `dest_airport_name` varchar(40) NOT NULL,
  `dest_city` varchar(20) NOT NULL,
  `dest_country` varchar(30) NOT NULL,
  `depature_dateTime` datetime NOT NULL,
  `landing_dateTime` datetime NOT NULL,
  `cost_buss_class` int(11) NOT NULL,
  `cost_first_clas` int(11) NOT NULL,
  `cost_economy_class` int(11) NOT NULL,
  `num_of_tickets` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `flightdetails`
--

INSERT INTO `flightdetails` (`id`, `flight_number`, `airways_name`, `origin_airport_name`, `origin_city`, `origin_country`, `dest_airport_name`, `dest_city`, `dest_country`, `depature_dateTime`, `landing_dateTime`, `cost_buss_class`, `cost_first_clas`, `cost_economy_class`, `num_of_tickets`) VALUES
(1, 'WS123456', 'Canada Air', 'RG International airport', 'india', 'india', 'YUL dearAirport', 'canada', 'canada', '2021-06-30 18:31:00', '2021-07-01 09:34:00', 102000, 85001, 60000, 50),
(6, 'ADY986362', 'airCanada', 'YML Airport', 'canada', 'canada', 'RG International airport', 'india', 'india', '2021-06-20 18:15:00', '2021-06-21 07:20:00', 120000, 85000, 62000, 65),
(7, 'R98345', 'Vandhematharam', 'Vijayawada International Airport', 'Vijayawada', 'india', 'YYZ International Airporta', 'Toronto', 'canada', '2021-06-26 02:50:00', '2021-06-27 16:52:00', 80000, 700000, 58000, 51),
(9, 'P23468', 'qatar', 'Rajiv gandhi airport', 'hyderabad', 'india', 'WR international airport', 'doha', 'qatar', '2021-06-30 15:20:00', '2021-07-01 05:20:00', 32000, 20000, 15000, 74),
(13, 'GH123456', 'JetAirways', 'RG International airport', 'new york', 'united states', 'YUL dearAirport', 'Montreal', 'Canada', '2021-07-09 10:30:00', '2021-07-09 16:36:00', 50000, 40000, 35000, 60);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_reservations`
--

CREATE TABLE `ticket_reservations` (
  `id` int(11) NOT NULL,
  `passeger_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL,
  `ticket_class` varchar(10) NOT NULL,
  `date_of_reservation` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ticket_reservations`
--

INSERT INTO `ticket_reservations` (`id`, `passeger_id`, `flight_id`, `ticket_class`, `date_of_reservation`) VALUES
(2, 5, 1, 'Economy', '2021-06-18'),
(10, 2, 1, 'First', '2021-06-25'),
(16, 5, 1, 'First', '2021-07-01'),
(19, 5, 9, 'Economy', '2021-06-29');

--
-- Triggers `ticket_reservations`
--
DELIMITER $$
CREATE TRIGGER `confirmTicket` AFTER INSERT ON `ticket_reservations` FOR EACH ROW update flightdetails set num_of_tickets=num_of_tickets-1 where new.flight_id=id
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `delete_ticket` AFTER DELETE ON `ticket_reservations` FOR EACH ROW update flightdetails set num_of_tickets=num_of_tickets+1
where old.flight_id=id
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `id` int(11) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email_Id` varchar(40) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `user_type` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`id`, `first_name`, `last_name`, `email_Id`, `phone`, `password`, `user_type`) VALUES
(2, 'sampurna', 'aila', 'sampurna1@gmail.com', '9876526621', 'sam1234', 'user'),
(5, 'swetha', 'mirupula', 'swetha1234@gmail.com', '8965431201', 'swetha', 'user'),
(7, 'uma', 'chiluka', 'uma1234@gmail.com', '3563572621', '12345', 'admin'),
(9, 'Ganesh', 'Reddy', 'ganeshReddy8@gmail.com', '8375831023', 'ganni', 'admin'),
(10, 'Madhavi', 'gaddampally', 'madhavi123@gmail.com', '5124189123', 'madhura', 'admin'),
(11, 'ganesh', 'gdm', 'ganeshgg@gmail.com', '5672348901', 'ganeshg', 'user'),
(14, 'Parth', 'sh', 'parthshah@gmail.com', '5673451234', 'parth', 'admin');

--
-- Triggers `user_info`
--
DELIMITER $$
CREATE TRIGGER `delete_user` BEFORE DELETE ON `user_info` FOR EACH ROW DELETE from ticket_reservations where old.id=passeger_id
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `flightdetails`
--
ALTER TABLE `flightdetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `flight_number_2` (`flight_number`,`depature_dateTime`);

--
-- Indexes for table `ticket_reservations`
--
ALTER TABLE `ticket_reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pas_id` (`passeger_id`),
  ADD KEY `f_id` (`flight_id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `first_name` (`first_name`,`last_name`),
  ADD UNIQUE KEY `email_Id` (`email_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `flightdetails`
--
ALTER TABLE `flightdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `ticket_reservations`
--
ALTER TABLE `ticket_reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user_info`
--
ALTER TABLE `user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ticket_reservations`
--
ALTER TABLE `ticket_reservations`
  ADD CONSTRAINT `f_id` FOREIGN KEY (`flight_id`) REFERENCES `flightdetails` (`id`),
  ADD CONSTRAINT `pas_id` FOREIGN KEY (`passeger_id`) REFERENCES `user_info` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
