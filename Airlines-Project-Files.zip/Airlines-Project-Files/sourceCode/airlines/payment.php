<!DOCTYPE html>

<html>
<head>
	<title>Home Page</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

      <!-- Font Awesome JS -->
      <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
      <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


  <!-- jQuery CDN - Slim version (=without AJAX) -->
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <!-- Popper.JS -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
      <!-- Bootstrap JS -->
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="home.css">
  <script>
  $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
						$('#logout').on('click', function () {
								window.location="index.php";
						});

        });
  </script>
  </head>
  <body>

		<?php
    include 'connectdb.php';
    $conn = OpenCon();// Using database connection file here
		session_start();
		if($_GET)
    {
			$id=$_GET['id'];
		}
		$cost=0;
		$tikClass="";

		?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <ul class="list-unstyled components">
                <p><b>Welcome <?php echo $_SESSION['name']; ?> </b></p>
                <li class="active">
                    <a href="#"><b>View Flights</b></a>
                </li>
                <li>
                    <a href="userTickets.php">View tickets</a>
                </li>
                <li>
                    <a href="updateInfo.php">Update PersonalInfo</a>
                </li>
                <li>
                    <a href="changePassword.php">Change Password</a>
                </li>
            </ul>

        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Toggle Sidebar</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
										<button type="button" id="logout" class="btn btn-info">
											<i class="fa-align-right"></i>
											<span>Logout</span>
										</button>
                </div>
            </nav>
						<!-- here code -->
				<div>
					<form method="get" style="padding:0px 40px;"action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
						<div class="form-row">
							<input type="text" class="form-control" name="id" value='<?php echo $id ?>' placeholder="flight-Id" hidden>
            <div class="form-group col-md-4">
							<label>Ticket class</label>
							<select name="ticketClass" class="form-control" value="<?php echo $ticketClass; ?>" onchange="this.form.submit()">
	        				<option value="" >--select class--</option>
	        				<option value="cost_buss_class">Bussiness class</option>
	        				<option value="cost_first_clas">First class</option>
	        				<option value="cost_economy_class">Economy class</option>
	    				</select>
						</div>
					</div>
					</form>

					<?php
					if(isset($_GET["ticketClass"])){
       				$tcls=$_GET["ticketClass"];
							$ticketClass=$tcls;
							$id=$_GET["id"];
							$sql="select $tcls from flightdetails where id=$id";
							$tikClass=" ";
							if($tcls=='cost_buss_class'){
								$tikClass="Business";
							}else if($tcls=='cost_first_clas'){
								$tikClass="First";
							}
							else if($tcls=='cost_economy_class'){
										$tikClass="Economy";
							}
							$result = $conn->query($sql);
							if($result){
									if ($result->num_rows > 0) {
											while ($row = $result->fetch_assoc()) {
												$cost=$row[$tcls];
											}
										}
									}
								}
	 				?>
				  <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
						<div class="form-row">
							<input type="text" class="form-control" name="id" value='<?php echo $id ?>' placeholder="flight-Id" hidden>
              <div class="form-group col-md-4">
								<label>Ticket-Price</label>
								<input type="text" class="form-control" name="cost" value='<?php echo $cost; ?>' placeholder="Enter First Name" required>
							</div>
							<div class="form-group col-md-1">
              </div>
							<div class="form-group col-md-4">
								<label>Ticket-class</label>
								<input type="text" class="form-control" name="ticketClass" value='<?php echo $tikClass; ?>' placeholder="Enter First Name" required>
							</div>
						</div>
						<div class="form-row">
              <div class="form-group col-md-4">
								<label><b>Procced to Payment : </b></label>
							</div>
						</div>
           <div class="form-row">
             <div class="form-group col-md-4">
               <label>First-Name</label>
               <input type="text" class="form-control" name="firstName" placeholder="Enter First Name" required>
             </div>
             <div class="form-group col-md-1">
             </div>
             <div class="form-group col-md-4">
               <label>LastName</label>
               <input type="text" class="form-control" name="lastName" placeholder="Enter Last Name" required>
             </div>
           </div>
           <div class="form-row">
             <div class="form-group col-md-4">
               <label>Card-Number</label>
               <input type="number" class="form-control" name="cardNum" placeholder="credit/debit card Number" required>
             </div>
             <div class="form-group col-md-1">
            </div>
             <div class="form-group col-md-4">
               <label>CVV</label>
               <input type="number" class="form-control" name="cvv" placeholder="enter CVV" required>
             </div>
           </div>
           <div class="form-row">
             <div class="form-group col-md-4">
               <label>Expiry-Date</label>
               <input type="datetime-local" class="form-control" name="expiryDate"  required>
             </div>
             <div class="form-group col-md-1">
            </div>
             <div class="form-group col-md-4">
               <label>Postal-Code</label>
               <input type="text" class="form-control" name="postal" placeholder="Enter postal code" required>
             </div>
           </div>
           <br>
           <button type="submit" class="btn btn-primary">Proceed</button>
          </form>
        </div>

				<?php
				if($_SERVER['REQUEST_METHOD']=="POST"){
						$tcls=$_POST["ticketClass"];
						echo "select country is => ".$tcls;
						$id=$_POST["id"];
						$userid=$_SESSION['id'];
						$bookDate=date("Y.m.d");



						if($userid && $id && $tcls && $bookDate ){

								 $sql = "INSERT INTO ticket_reservations (passeger_id,flight_id,ticket_class,date_of_reservation)
										 VALUES ($userid,$id,'$tcls','$bookDate');";


			 // if the insert query return true display message registered successfully
			 if ($conn->query($sql) === TRUE) {
				 // display a message registered successfully
				 echo "<script>alert('ticket booked successfully');</script>";
				 echo  '<script>
							 window.location="payment.php";</script>';


			 } else {
				 //if the record cannot insert means studentId already exist. error message.
				 echo "<script>alert('Sorry, ticket not booked exist');</script>";

			 }
		 }
		 else{
			 echo "<script>alert('Sorry, please enter all the details ');</script>";
		 }
		}

				?>

    </div>

  </body>
</html>
