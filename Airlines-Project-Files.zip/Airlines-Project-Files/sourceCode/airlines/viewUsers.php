<!DOCTYPE html>

<html>
<head>
	<title>Home Page</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
		<!-- Font Awesome JS -->
				<meta name='viewport' content='width=device-width, initial-scale=1'>
			<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
			<script defer src="https://use.fontawesome.com/releases/v5.0.13/js/all.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
			<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
	<!-- jQuery CDN - Slim version (=without AJAX) -->
			<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
			<!-- Popper.JS -->
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
			<!-- Bootstrap JS -->
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

		<link rel="stylesheet" type="text/css" href="home.css">
  <script>
  $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
						$('#logout').on('click', function () {
								window.location="index.php";
						});
        });
  </script>
  </head>
  <body>
		<?php
		 include 'connectdb.php';
		 $conn = OpenCon();
		 session_start();
		 $sql = "SELECT * FROM user_info";
		 $result = $conn->query($sql);
		?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <ul class="list-unstyled components">
                <p><b>Welcome <?php echo $_SESSION['name']; ?></b></p>
                <li >
                    <a href="homePage.php"><b>View Flights</b></a>
                </li>
                <li>
                    <a href="flight.php">Add Flight</a>
                </li>
                <li>
                    <a href="viewTickets.php">View tickets</a>
                </li>
                <li class="active">
                    <a href="#">View users</a>
                </li>
                <li>
                    <a href="admin.php">Add Admin</a>
                </li>
            </ul>

        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Toggle Sidebar</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
										<button type="button" id="logout" class="btn btn-info">
											<i class="fa-align-right"></i>
											<span>Logout</span>
										</button>
                </div>
            </nav>
						<!-- here code -->
						<?php if($result){ ?>
							<table class="table table-bordered">
								<thead>
									<tr class="bg-info">
										<td hidden>Id</td>
										<td>FirstName</td>
										<td>LastName</td>
										<td>Email Id</td>
										<td>Phone</td>
										<td>Update</td>
										<td>Delete</td>
									</tr>
								</thead>
								<?php

			 // check the result has data or not
								if ($result->num_rows > 0) {
									// irrating values from result
									while ($row = $result->fetch_assoc()) {

								 // getting values from row to php variables to display in table
								 $userId = $row['id'];
								 $firstName = $row['first_name'];
								 $lastName = $row['last_name'];
								 $emailId = $row['email_Id'];
								 $phone = $row['phone'];
							 ?>
							 <tbody>
							 <tr>
									 <td hidden> <?php echo "$userId"; ?> </td>
									 <td> <?php echo "$firstName"; ?> </td>
									 <td> <?php echo "$lastName"; ?> </td>
									 <td> <?php echo "$emailId"; ?> </td>
									 <td> <?php echo "$phone"; ?> </td>
									 <td><a  href="updateUserInfo.php?id=<?php echo $userId; ?>" class='fas fa-edit' style='font-size:25px;color:#008B8B'></a></td>
									 <td><a href="deleteUser.php?id=<?php echo $userId; ?>" class='fas fa-trash-alt' style='font-size:25px;color:#008B8B'></a></td>
								 </tr>
								 <?php
						 }
				 ?>
					 </tbody>
					 </table>
							<?php
						}else {
								echo "*** No users Found ***";
							}
						}
				?>
        </div>
    </div>

  </body>
</html>
