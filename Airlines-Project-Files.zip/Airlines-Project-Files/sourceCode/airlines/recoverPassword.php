<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
   <!--Made with love by Mutiullah Samim -->

	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<link rel="stylesheet" type="text/css" href="styles.css">
  <script type="text/javascript">
  var check = function() {
         if (document.getElementById('newPassword').value ==
           document.getElementById('confirmPassword').value &&(document.getElementById('newPassword').value!="" && document.getElementById('confirmPassword').value!="")) {
           document.getElementById('message').style.color = 'green';
           document.getElementById('message').innerHTML = 'matching';
         } else if(document.getElementById('newPassword').value!="" && document.getElementById('confirmPassword').value!="") {
           document.getElementById('message').style.color = 'red';
           document.getElementById('message').innerHTML = 'not matching';
         }
         else{
           document.getElementById('message').innerHTML = '';
         }
       }

  </script>
</head>
<body>

	<?php
  include 'connectdb.php';
  $conn = OpenCon();
  session_start();
  $id=$_SESSION['id'];
	 ?>
<div class="container">
	<div class="d-flex justify-content-center h-100">
		<div class="card" style="width:50%;height:50%">
			<div class="card-header">
				<h3>Recover Password</h3>
			</div>
			<div class="card-body"  style="align-items:center;margin-left:30px;padding-right:0px;color:white">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <div class="form-row">
        <div class="form-group col-md-4">
            <label>New Password</label>
        </div>
           <div class="form-group col-md-6">
             <input type="password" class="form-control" id="newPassword" name="newPassword" placeholder="Enter New Password" onkeyup='check();' />
           </div>
          </div>
          <br>
          <div class="form-row">
          <div class="form-group col-md-4">
              <label>Confirm Password</label>
            </div>
            <div class="form-group col-md-6">
              <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" placeholder="Confirm New Password" onkeyup='check();' />
               <span id='message'></span>
            </div>
          </div>
          <br>
         <button type="submit" class="btn btn-info">change Password</button>
        </form>
			</div>
		</div>
	</div>
</div>
<?php

				 //To execute code only if button submitted
				 if($_SERVER['REQUEST_METHOD']=="POST"){

					//SHOULD VALIDATE TWO PASSWORDS BEFORE INSERTING
					echo "Im inside the request method";
					// getting values from post request
							$newPass= $_POST['newPassword'];
              $oldPass= $_POST['oldPassword'];

				 if($oldPass && $newPass){

							$sql = "Update user_info set password='$newPass' where id=$id and password='$oldPass'";


		// if the insert query return true display message registered successfully
		if ($conn->query($sql) === TRUE) {
			// display a message registered successfully
			echo "<script>alert('Password changed successfully');</script>";
			$message="information updated successfully";
			echo " <h3>$message</h3>";
		} else {
			//if the record cannot insert means studentId already exist. error message.
			echo "<script>alert('Sorry, something is wrong');</script>";

		}
	}
 }
		?>
    <?php

    				 //To execute code only if button submitted
    				 if($_SERVER['REQUEST_METHOD']=="POST"){

    					//SHOULD VALIDATE TWO PASSWORDS BEFORE INSERTING
    					echo "Im inside the request method";
    					// getting values from post request
    							$newPass= $_POST['newPassword'];

    				 if($newPass){

    							$sql = "Update user_info set password='$newPass' where id=$id ";


    		// if the insert query return true display message registered successfully
    		if ($conn->query($sql) === TRUE) {
    			// display a message registered successfully
    			echo "<script>alert('Password changed successfully');</script>";
    			$message="information updated successfully";
    			echo " <h3>$message</h3>";
    		} else {
    			//if the record cannot insert means studentId already exist. error message.
    			echo "<script>alert('Sorry, something is wrong');</script>";

    		}
    	}
     }
    		?>
</body>
</html>
