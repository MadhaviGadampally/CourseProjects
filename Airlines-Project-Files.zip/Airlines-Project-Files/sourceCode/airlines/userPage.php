<!DOCTYPE html>

<html>
<head>
	<title>Home Page</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

      <!-- Font Awesome JS -->
      <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
      <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


  <!-- jQuery CDN - Slim version (=without AJAX) -->
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <!-- Popper.JS -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
      <!-- Bootstrap JS -->
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="home.css">
  <script>
  $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
						$('#logout').on('click', function () {
								window.location="index.php";
						});
        });
  </script>
  </head>
  <body>

		<?php
		 include 'connectdb.php';
		 $conn = OpenCon();
		 session_start();
		 $sql = "SELECT * FROM flightdetails";
		 $result = $conn->query($sql);

		?>
    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <ul class="list-unstyled components">
                <p><b>Welcome <?php echo $_SESSION['name']; ?> </b></p>
                <li class="active">
                    <a href="#"><b>View Flights</b></a>
                </li>
                <li>
                    <a href="userTickets.php">View tickets</a>
                </li>
                <li>
                    <a href="updateInfo.php">Update PersonalInfo</a>
                </li>
                <li>
                    <a href="changePassword.php">Change Password</a>
                </li>
            </ul>

        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Toggle Sidebar</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
										<button type="button" id="logout" class="btn btn-info">
											<i class="fa-align-right"></i>
											<span>Logout</span>
										</button>
                </div>
            </nav>
						<!-- here code -->
						<?php if($result){ ?>
			        <table id="flightInfo" class="table table-bordered" >
			            <tr class="bg-info">
										<td>Flight Id</td>
			              <td>Flight Number</td>
			              <td>Airways</td>
			              <td>Origin Airport</td>
										<td>Origin country</td>
										<td>Destination Airport</td>
										<td>Destination Country</td>
										<td>Depature Date&Time</td>
										<td>Landing Date&Time</td>
										<td>Bussiness Class Cost</td>
										<td>First Class Cost</td>
										<td>Economy Class Cost</td>
										<td>Available Tickets</td>
										<td>Update Data</td>
									</tr>
								<?php

			 // check the result has data or not
								if ($result->num_rows > 0) {
									// irrating values from result
									while ($row = $result->fetch_assoc()) {

								 // getting values from row to php variables to display in table
								 $flightId = $row['id'];
								 $flightNumber = $row['flight_number'];
								 $airways = $row['airways_name'];
								 $orgAirport = $row['origin_airport_name'];
								 $orgCountry = $row['origin_city'];
								 $destAirport = $row['dest_airport_name'];
								 $destCountry = $row['dest_city'];
								 $deptTime = $row['depature_dateTime'];
								 $landTime = $row['landing_dateTime'];
								 $busiCls = $row['cost_buss_class'];
								 $firstCls = $row['cost_first_clas'];
								 $econCls = $row['cost_economy_class'];
								 $numTickets= $row['num_of_tickets'];
			 				 ?>
							 <tbody>
			 				 <tr>
								 	<td> <?php echo "$flightId"; ?> </td>
									 <td> <?php echo "$flightNumber"; ?> </td>
									 <td> <?php echo "$airways"; ?> </td>
									 <td> <?php echo "$orgAirport"; ?> </td>
									 <td> <?php echo "$orgCountry"; ?> </td>
									 <td> <?php echo "$destAirport"; ?> </td>
									 <td> <?php echo "$destCountry"; ?> </td>
									 <td> <?php echo "$deptTime"; ?> </td>
									 <td> <?php echo "$landTime"; ?> </td>
									 <td> <?php echo "$busiCls"; ?> </td>
									 <td> <?php echo "$firstCls"; ?> </td>
									 <td> <?php echo "$econCls"; ?> </td>
									 <td> <?php echo "$numTickets"; ?> </td>
									 <td><a  href="payment.php?id=<?php echo $flightId; ?>" class="btn btn-info"> Book </a></td>
								 </tr>
								 <?php
						 }
				 ?>
					 </tbody>
					 </table>
        </div>
				<?php
			}else {
	        echo "*** No Flights Found in this slot ***";
	      }
	    }
	?>
    </div>

  </body>
</html>
