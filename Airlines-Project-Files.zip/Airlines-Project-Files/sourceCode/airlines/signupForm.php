<!DOCTYPE html>
<html>
<head>
	<title>Signup Page</title>
   <!--Made with love by Mutiullah Samim -->

	<!--Bootsrap 4 CDN-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
  <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

	<?php
		include 'connectdb.php';
		$conn = OpenCon();
		session_start();
		$message=" ";
	 ?>
<div class="container">
	<div class="d-flex justify-content-center h-100">
		<div class="card" style="width:60%;height:70%">
			<div class="card-header">
				<a href="index.php" class="btn float-right btn-danger">x</a>
				<h3>Signup</h3>
			</div>
      	<div class="card-body" style="align-items:center;margin-left:30px;padding-right:0px;color:white">
				<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>FirstName</label>
              <input type="text" class="form-control" name="firstName" placeholder="Enter First Name" required>
            </div>
            <div class="form-group col-md-1">
            </div>
            <div class="form-group col-md-4">
              <label>LastName</label>
              <input type="text" class="form-control" name="lastName" placeholder="Enter Last Name" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>Phone-Number</label>
              <input type="text" class="form-control" name="phone" placeholder="Enter Phone Number" required>
            </div>
            <div class="form-group col-md-1">
           </div>
            <div class="form-group col-md-4">
              <label>Email-Id</label>
              <input type="email" class="form-control" name="emailId" placeholder="Email-Id" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-group col-md-4">
              <label>Choose-password</label>
              <input type="password" class="form-control" name="pass1" placeholder="choose password" required>
            </div>
            <div class="form-group col-md-1">
           </div>
            <div class="form-group col-md-4">
              <label>Re-enter Password</label>
              <input type="password" class="form-control" name="pass2" placeholder="Re-enter Password" required>
            </div>
          </div>
					<div class="form-row">
					<div class="form-group col-md-3">
						<button type="submit"  class="btn btn-primary">Add User</button>
					</div>
					<div class="form-group col-md-3">
					 <input type="reset" class="btn btn-primary" value="Reset">
					 </div>
				 </div>

				</form>
      </div>
		</div>
	</div>
</div>
<?php

				 //To execute code only if button submitted
				 if($_SERVER['REQUEST_METHOD']=="POST"){

					//SHOULD VALIDATE TWO PASSWORDS BEFORE INSERTING
					echo "Im inside the request method";
					// getting values from post request
						 	$firstName= $_POST['firstName'];
							$lastName= $_POST['lastName'];
							$phone= $_POST['phone'];
							$emailId= $_POST['emailId'];
							$password= $_POST['pass1'];

				 if($firstName && $lastName && $phone && $emailId && $password ){

							$sql = "INSERT INTO user_info (first_name,last_name,email_Id,phone,password,user_type)
									VALUES ('$firstName','$lastName','$emailId','$phone','$password','user')";

		// if the insert query return true display message registered successfully
		if ($conn->query($sql) === TRUE) {
			// display a message registered successfully
			echo "<script>alert('admin details added successfully');</script>";
			$message="Your account created successfully";
			echo " <h3>$message</h3>";
		} else {
			//if the record cannot insert means studentId already exist. error message.
			echo "<script>alert('Sorry, emailId or name is already exist');</script>";

		}
	}
 }
		?>
</body>
</html>
