<?php

include 'connectdb.php';
$conn = OpenCon();// Using database connection file here
 //$arr = unserialize($_GET["data"]);
$id=$_GET['id'];
echo $id;
// get id through query string

$sql = "delete from flightdetails where id = $id"; // delete query

if ($conn->query($sql) === TRUE) {
  // display a message registered successfully
  echo "<script>alert('flight details deleted successfully');</script>";
  echo   '<script>
          window.location="homePage.php";</script>';
} else {
  //if the record cannot insert means studentId already exist. error message.
  echo "<script>alert('Sorry, something is wrong');</script>";
  echo   '<script>
          window.location="homePage.php";</script>';

}
?>
