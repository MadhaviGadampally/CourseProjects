<!DOCTYPE html>
<html lang="" dir="ltr">
  <head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  </head>
  <body>
    <nav class="navbar navbar-inverse">
      <ul class="nav navbar-nav">
          <li><a href="#">User</a></li>
          <li class="active"><a href="#">admin</a></li>
        </ul>
    </nav>
          <div class="container">
            <h2>Admin Login here</h2>
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
              <div class="form-group">
                <label>Email:</label>
                <input type="text" class="form-control" placeholder="Enter email" name="username">
              </div>
              <div class="form-group">
                <label>Password:</label>
                <input type="password" class="form-control" placeholder="Enter password" name="pwd">
              </div>
              <div class="checkbox">
                <label><input type="checkbox" name="remember"> Remember me</label>
              </div>
              <button type="submit" class="btn btn-default">Submit</button>
            </form>
          </div>

          <?php
          		include 'connectdb.php';
          		$conn = OpenCon();
          		session_start();
                //To execute code only if button submitted
                if($_SERVER['REQUEST_METHOD']=="POST"){

                // getting values from post request
                $username= $_POST['username'];
                $password= $_POST['pwd'];
          			if($username && $password){
                  // query to check the slot count.
                  $check="SELECT * FROM login_details WHERE email_id='$username' and password='$password'";
                  $result = $conn->query($check);
                  if ($result->num_rows> 0) {
                    $_SESSION['username']=$_POST['username'];
                    echo "Im inside result condition ";
                    header("location:homepage.php");
                    exit();
                  }
                  else
                  {
                    $_SESSION['msg1']="Invalid Username or Password";
                  }
          			}
          		}

          ?>
  </body>
</html>
