<?php

include 'connectdb.php';
$conn = OpenCon();// Using database connection file here
 //$arr = unserialize($_GET["data"]);
$id=$_GET['id'];
echo $id;
// get id through query string
// delete query
$sql = "delete from user_info where id = $id";

echo $sql;

if ($conn->query($sql) === TRUE) {
  // display a message registered successfully
  echo "<script>alert('user details deleted successfully');</script>";
  echo   '<script>
          window.location="viewUsers.php";</script>';
} else {
  //if the record cannot insert means studentId already exist. error message.
  echo "<script>alert('Sorry, something is wrong');</script>";
  echo   '<script>
          window.location="viewUsers.php";</script>';

}
?>
