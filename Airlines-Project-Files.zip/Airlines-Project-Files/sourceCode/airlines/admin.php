<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">

      <!-- Font Awesome JS -->
      <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
      <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


  <!-- jQuery CDN - Slim version (=without AJAX) -->
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
      <!-- Popper.JS -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
      <!-- Bootstrap JS -->
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="home.css">
  <script>
  $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
						$('#logout').on('click', function () {
								window.location="index.php";
						});
        });
  </script>
  </head>
  <body>

		<?php
			include 'connectdb.php';
			$conn = OpenCon();
			session_start();
			?>

    <div class="wrapper">
        <!-- Sidebar  -->
        <nav id="sidebar">
            <ul class="list-unstyled components">
                <p><b>Welcome <?php echo $_SESSION['name']; ?></b></p>
                <li>
                    <a href="homePage.php">View Flights</a>
                </li>
                <li>
                    <a href="flight.php">Add Flight</a>
                </li>
                <li>
                    <a href="viewTickets.php">View tickets</a>
                </li>
                <li>
                    <a href="viewUsers.php">View users</a>
                </li>
                <li class="active">
                    <a href="#">Add Admin</a>
                </li>
            </ul>

        </nav>

        <!-- Page Content  -->
        <div id="content">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span>Toggle Sidebar</span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>
										<button type="button" id="logout" class="btn btn-info">
											<i class="fa-align-right"></i>
											<span>Logout</span>
										</button>
                </div>
            </nav>
						<!-- here code -->
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
             <div class="form-row">
               <div class="form-group col-md-4">
                 <label>FirstName</label>
                 <input type="text" class="form-control" name="firstName" placeholder="Enter First Name" required>
               </div>
							 <div class="form-group col-md-1">
							 </div>
               <div class="form-group col-md-4">
                 <label>LastName</label>
                 <input type="text" class="form-control" name="lastName" placeholder="Enter Last Name" required>
               </div>
             </div>
             <div class="form-row">
               <div class="form-group col-md-4">
                 <label>Phone-Number</label>
                 <input type="number" class="form-control" name="phone" placeholder="Enter Phone Number" required>
               </div>
							 <div class="form-group col-md-1">
							</div>
							 <div class="form-group col-md-4">
                 <label>Email-Id</label>
                 <input type="email" class="form-control" name="emailId" placeholder="Email-Id" required>
               </div>
             </div>
             <div class="form-row">
               <div class="form-group col-md-4">
                 <label>Choose-password</label>
                 <input type="password" class="form-control" name="pass1" placeholder="choose password" required>
               </div>
							 <div class="form-group col-md-1">
							</div>
							 <div class="form-group col-md-4">
	               <label>Re-enter Password</label>
	               <input type="password" class="form-control" name="pass2" placeholder="Re-enter Password" required>
	             </div>
             </div>
						 <br>
             <button type="submit" class="btn btn-info">Add Admin</button>
            </form>
        </div>
    </div>
<?php

				 //To execute code only if button submitted
				 if($_SERVER['REQUEST_METHOD']=="POST"){

					//SHOULD VALIDATE TWO PASSWORDS BEFORE INSERTING
					echo "Im inside the request method";
					// getting values from post request
						 	$firstName= $_POST['firstName'];
							$lastName= $_POST['lastName'];
							$phone= $_POST['phone'];
							$emailId= $_POST['emailId'];
							$password= $_POST['pass1'];

				 if($firstName && $lastName && $phone && $emailId && $password ){

							$sql = "INSERT INTO user_info (first_name,last_name,email_Id,phone,password,user_type)
									VALUES ('$firstName','$lastName','$emailId','$phone','$password','admin')";

		// if the insert query return true display message registered successfully
		if ($conn->query($sql) === TRUE) {
			// display a message registered successfully
			echo "<script>alert('admin details added successfully');</script>";
			$message="admin added successfully";
			echo " <h3>$message</h3>";
		} else {
			//if the record cannot insert means studentId already exist. error message.
			echo "<script>alert('Sorry, emailId or name is already exist');</script>";

		}
	}
 }
		?>
  </body>
</html>
